# Killamsetty Rahul Portfolio

A responsive static portfolio website created from Rahul's supplied professional profile and verified resume/certificate data.

## Run locally

Open `index.html` directly, or run a local server:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy

Upload the folder to Vercel, Netlify, GitHub Pages, or any static host. No build step is required.

## Customize

- Edit content in `index.html`.
- Adjust colors and layout in `styles.css`.
- Update the local AI Twin knowledge in `script.js`.
- Replace the email and LinkedIn URLs if desired.

The AI Twin is a local rule-based assistant and does not call an external AI API.
